FFmpeg 64-bit static Windows builds from www.gyan.dev

Version: 4.3.1-essentials_build-www.gyan.dev

License: GPL v3

Source Code: https://github.com/FFmpeg/FFmpeg/commit/6d886b6586

release-essentials build configuration: 

    --enable-gpl
    --enable-version3
    --enable-static
    --disable-w32threads
    --disable-autodetect
    --enable-fontconfig
    --enable-iconv
    --enable-gnutls
    --enable-libxml2
    --enable-gmp
    --enable-lzma
    --enable-zlib
    --enable-libsrt
    --enable-libssh
    --enable-libzmq
    --enable-avisynth
    --enable-sdl2
    --enable-libwebp
    --enable-libx264
    --enable-libx265
    --enable-libxvid
    --enable-libaom
    --enable-libopenjpeg
    --enable-libvpx
    --enable-libass
    --enable-libfreetype
    --enable-libfribidi
    --enable-libvidstab
    --enable-libvmaf
    --enable-libzimg
    --enable-amf
    --enable-cuda-llvm
    --enable-cuvid
    --enable-ffnvcodec
    --enable-nvdec
    --enable-nvenc
    --enable-d3d11va
    --enable-dxva2
    --enable-libmfx
    --enable-libgme
    --enable-libopenmpt
    --enable-libopencore-amrwb
    --enable-libmp3lame
    --enable-libtheora
    --enable-libvo-amrwbenc
    --enable-libgsm
    --enable-libopencore-amrnb
    --enable-libopus
    --enable-libspeex
    --enable-libvorbis
    --enable-librubberband
